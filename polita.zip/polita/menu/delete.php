<?php

include "../config.php";
$id = $_GET["id"];
session_start();
if ($_SESSION["admin"] == "") {
    echo "
    <script>
        document.location.href = '../auth/login.php'
    </script>
    ";
}

function delete($id)
{
    global $connection;
    mysqli_query($connection,"delete from tb_menu where id_menu = $id");
    return mysqli_affected_rows($connection);
}

if(delete($id) > 0)
{
    echo "
    <script>
        document.location.href = '../admin/index.php'
    </script>
    ";
}

?>