<?php

include "../config.php";
session_start();
if ($_SESSION["admin"] == "") {
    echo "
    <script>
        document.location.href = '../auth/login.php'
    </script>
    ";
}
$id = $_GET["id"];

$data = mysqli_query($connection,"SELECT * FROM tb_menu WHERE id_menu = $id");
$row = mysqli_fetch_assoc($data);

function updateMenu($data)
{

    global $connection;

    $id = $data["id_menu"];
    $name = $data["name"];
    $price = $data["price"];
    $imageOld = $data["imageOld"];
    // var_dump($imageOld);
    // die;

    if($_FILES["image_name"]["error"] === 4){
        $image_menu = $imageOld;
    }else{
        $image_menu = imageMenu();
    }

    mysqli_query($connection, "UPDATE tb_menu SET
        name_menu = '$name',
        price_menu = '$price',
        image_menu = '$image_menu'
        WHERE id_menu = $id
    ");

    return mysqli_affected_rows($connection);
}

function imageMenu(){

    $nameFile = $_FILES["image_name"]["name"];
    $tempName = $_FILES["image_name"]["tmp_name"];
    $error = $_FILES["image_name"]["error"];

    // check if no images are uploaded
    if( $error === 4 ){
        echo "please upload image!";
    }

    // check extension image
    $extension = ["jpg","png","jpeg","jfif"];
    $extensionImage = explode(".",$nameFile);
    $extensionImage = strtolower(end($extensionImage));
    
    if( !in_array($extensionImage,$extension) ){
        echo "this file not image";
    }
    
    // change name image from default to random string
    $newName = uniqid();
    $newName .= ".";
    $newName .= $extensionImage;

    move_uploaded_file($tempName, '../img/menu/' . $newName);

    return $newName;
}

if (isset($_POST["submit"])) {
    if (updateMenu($_POST) > 0) {
        echo "
        <script>
            alert('data berhasil di ubah')
            document.location.href = '../admin/index.php'
        </script>
        ";
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../dist/output.css">
</head>
<body class="bg-blue-200">
<div class="w-full h-screen flex justify-center items-center">
        <form action="" method="post" enctype="multipart/form-data" class="bg-white flex justify-center items-center flex-col w-3/4 h-3/5 rounded shadow-lg py-2">
        <input type="hidden" name="id_menu" value="<?= $row["id_menu"] ?>">
            <input type="hidden" name="imageOld" value="<?= $row["image_menu"] ?>">
            <div class="w-full flex justify-center items-center mb-2">
                <span class="font-bold text-blue-800 text-3xl">Edit Menu</span>
            </div>
            <div class="w-full flex justify-center items-center mb-2">
                <img src="../img/menu/<?= $row["image_menu"] ?>" alt="" srcset="" class="h-32 w-32 rounded">
            </div>
            <div class="w-full flex justify-center items-center mb-2">
                <input type="text" name="name" value="<?= $row["name_menu"] ?>" placeholder="Menu Name" class="w-2/3 py-2 px-4 rounded font-semibold text-lg text-blue-700 focus:outline-none border-2 border-blue-200">
            </div>
            <div class="w-full flex justify-center items-center mb-2">
                <input type="number" name="price" placeholder="Price" value="<?= $row["price_menu"] ?>" class="w-2/3 py-2 px-4 rounded font-semibold text-lg text-blue-700 focus:outline-none border-2 border-blue-200">
            </div>
            <div class="w-full flex justify-center items-center mb-2">
                <input type="file" name="image_name" class="w-2/3 py-2 px-4 rounded font-semibold text-lg text-blue-700 focus:outline-none border-2 border-blue-200 file:bg-blue-300 file:border-none file:rounded file:text-blue-700 file:py-2 file:px-4">
            </div>
            <div class="flex justify-center w-full items-center mt-4">
                <button type="submit" name="submit" class="bg-blue-600 hover:bg-blue-500 outline outline-white py-2 w-1/3 font-semibold text-lg rounded text-white">Submit</button>
                <div class="mx-1"></div>
                <a href="../admin/index.php" class="bg-red-500 hover:bg-red-600 py-2 w-1/3 outline outline-white text-center font-semibold text-lg rounded text-white">Back</a>
            </div>
        </form>
    </div>
</body>
</html>