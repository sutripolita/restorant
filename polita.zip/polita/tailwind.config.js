/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./auth/*.{html,php}",
    "./admin/*.{html,php}",
    "./menu/*.{html,php}",
    "./user/*.{html,php}",
    "./index.{html,php}",
    "./crud-user/*.{html,php}"
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
