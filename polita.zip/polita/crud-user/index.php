<?php

include "../config.php";
session_start();
if ($_SESSION["admin"] == "") {
    echo "
    <script>
        document.location.href = '../auth/login.php'
    </script>
    ";
}

$users = mysqli_query($connection,"select * from tb_user")

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../dist/output.css">
</head>
<body class="bg-blue-200">
    <div class="flex justify-center items-center flex-col">
        <nav class="w-full py-4 px-8 border-b shadow-lg flex justify-between items-center bg-blue-400">
            <span class="text-xl font-bold">Selamat Datang, <?= $_SESSION["admin"] ?></span>
            <a href="../auth/logout.php" class="text-xl font-bold">Logout</a>
        </nav>
        <div class="w-full h-full container rounded py-2 bg-blue-400 flex justify-between">
            <div class="px-8 text-center">
                <a href="../admin/index.php" class="font-semibold text-lg py-2">Menu</a>
                <span class="mx-2 text-lg">|</span>
                <a href="index.php" class="font-semibold text-lg py-2">User</a>
            </div>
        </div>
        <div class="w-3/4 h-full bg-blue-100 border shadow-lg p-4 my-20">
            <table class="table-auto w-full h-full">
                <thead>
                    <tr>
                        <th class="p-3 border-b text-xl">Username</th>
                        <th class="p-3 border-b text-xl">status</th>
                        <th class="p-3 border-b text-xl">Action</th>
                    </tr>
                </thead>
                <?php while($row = mysqli_fetch_assoc($users)) : ?>
                <tbody>
                    <tr class="text-center">
                        <td class="p-3 border-b text-lg font-semibold"><?= $row["username"] ?></td>
                        <td class="p-3 border-b text-lg font-semibold"><?= $row["level"] ?></td>
                        <td class="p-3 border-b text-lg font-semibold">
                            <a href="./update.php?id=<?= $row["id_user"] ?>" class="text-blue-700">Edit</a> |
                            <a href="./delete.php?id=<?= $row["id_user"] ?>" class="text-red-700">Delete</a>
                        </td>
                    </tr>
                </tbody>
                <?php endwhile?>
            </table>
        </div>
    </div>
</body>
</html>