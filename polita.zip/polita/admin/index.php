<?php

include "../config.php";
session_start();
if ($_SESSION["admin"] == "") {
    echo "
    <script>
        document.location.href = '../auth/login.php'
    </script>
    ";
}

$menus = mysqli_query($connection,"select * from tb_menu")

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../dist/output.css">
</head>
<body class="bg-blue-100">
    <div class="flex justify-center items-center flex-col">
        <nav class="w-full py-4 px-8 border-b shadow-lg flex justify-between items-center bg-blue-400">
            <span class="text-xl font-bold">Selamat Datang, <?= $_SESSION["admin"] ?></span>
            <a href="../auth/logout.php" class="text-xl font-bold">Logout</a>
        </nav>
        <div class="w-full h-full py-2 bg-blue-400 flex justify-between container rounded">
            <div class="px-8 text-center">
                <a href="index.php" class="font-semibold text-lg py-2">Menu</a>
                <span class="mx-2 text-lg">|</span>
                <a href="../crud-user/index.php" class="font-semibold text-lg py-2">User</a>
            </div>
        </div>
        <div class="w-3/4 h-full bg-white border shadow-lg p-4 my-20">
            <div class="my-4">
                <a href="../menu/create.php" class="py-3 px-8 bg-blue-500 hover:bg-600 font-semibold text-lg rounded text-white">Add Menu</a>
            </div>
            <table class="table-auto w-full h-full">
                <thead>
                    <tr>
                        <th class="p-3 border-b text-xl">Menu</th>
                        <th class="p-3 border-b text-xl">Price</th>
                        <th class="p-3 border-b text-xl">Image</th>
                        <th class="p-3 border-b text-xl">Action</th>
                    </tr>
                </thead>
                <?php while($row = mysqli_fetch_assoc($menus)) : ?>
                <tbody>
                    <tr class="text-center">
                        <td class="p-3 border-b text-lg font-semibold"><?= $row["name_menu"] ?></td>
                        <td class="p-3 border-b text-lg font-semibold"><?= $row["price_menu"] ?></td>
                        <td class="p-3 border-b text-lg font-semibold flex justify-center items-center">
                            <img src="../img/menu/<?= $row["image_menu"] ?>" class="rounded h-20 w-20">
                        </td>
                        <td class="p-3 border-b text-lg font-semibold">
                            <a href="../menu/update.php?id=<?= $row["id_menu"] ?>" class="text-blue-700">Edit</a> |
                            <a href="../menu/delete.php?id=<?= $row["id_menu"] ?>" class="text-red-700">Delete</a>
                        </td>
                    </tr>
                </tbody>
                <?php endwhile?>
            </table>
        </div>
    </div>
</body>
</html>