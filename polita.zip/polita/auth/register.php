<?php

include('../config.php');
function register($data){
    global $connection;

    $username = $data["username"];
    $password = $data["password"];
    
    // check username
    $name = mysqli_query($connection,"SELECT * FROM tb_user WHERE username = '$username'");
    if(mysqli_fetch_assoc($name)){
        echo "
        <script>
            alert('username sudah terpakai')
        </script>
        ";
        return false;
    }

    // add data to database
    mysqli_query($connection,"INSERT INTO tb_user VALUES (
        '',
        '$username',
        '$password',
        'user'
        )
    ");

    return mysqli_affected_rows($connection);
}

if(isset($_POST["submit"])){
    if(register($_POST) > 0){
        echo"
        <script>
            alert('data berhasil di tambahkan')
            document.location.href = './login.php'
        </script>
        ";
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../dist/output.css">
</head>

<body class="bg-blue-200">
    <div class="w-full h-screen flex justify-center items-center">
        <form action="" method="post" class="bg-white flex justify-center items-center flex-col w-1/3 h-2/5 rounded shadow-lg">
            <div class="w-full flex justify-center items-center mb-2">
                <span class="font-bold text-blue-800 text-3xl">Register</span>
            </div>
            <div class="w-full flex justify-center items-center mb-2">
                <input type="text" name="username" placeholder="Username" class="w-2/3 py-2 px-4 rounded font-semibold text-lg text-blue-700 focus:outline-none border-2 border-blue-200">
            </div>
            <div class="w-full flex justify-center items-center mb-2">
                <input type="password" name="password" placeholder="Password" class="w-2/3 py-2 px-4 rounded font-semibold text-lg text-blue-700 focus:outline-none border-2 border-blue-200">
            </div>
            <div class="flex justify-center w-full items-center mt-4">
                <button type="submit" name="submit" class="bg-blue-600 hover:bg-blue-500 outline outline-white py-2 w-1/3 font-semibold text-lg rounded text-white">Submit</button>
                <div class="mx-1"></div>
                <a href="../index.php" class="bg-red-500 hover:bg-red-600 py-2 w-1/3 text-center outline outline-white font-semibold text-lg rounded text-white">Back</a>
            </div>
        </form>
    </div>
</body>

</html>