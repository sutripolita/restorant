<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./dist/output.css">
</head>

<body class="bg-gray-100">
    <div class="bg-blue-200 bg-cover absolute h-full w-full opacity-80 -z-10"></div>
    <div class="w-full h-full justify-center flex items-center flex-col">
        <nav class="w-full shadow-lg flex flex-row justify-end items-center py-4 px-8 bg-gradient-to-b from-gray-100">
            <a href="./auth/login.php" class="font-bold font-xl hover:text-white">Login</a>
            <span class="mx-2"> | </span>
            <a href="./auth/register.php" class="font-bold font-xl hover:text-white">Register</a>
        </nav>
        <span class="header w-full text-center font-bold text-4xl shadow py-4 px-8 container mt-20 bg-blue-400 text-white rounded-lg">
            Resto Seafood
        </span>
        <div class="w-full h-full flex justify-center flex-col items-center mt-2 shadow bg-white container rounded-lg">
            <div class="w-full h-full flex justify-center flex-col">
                <div class="w-full h-full flex justify-center items-center pb-4 pt-8 px-8 text-center">
                    <span class="w-1/2 pr-4">
                      Resto Seafood makanan yang berupa hewan dan tumbuhan laut yang ditangkap,dipancing,diambil dari laut maupun hasil budidaya.Makanan laut merupakan sumber protein,lemak,vitamin,dan mineral.DAN JUGA BANYAK MAKANAN ENAK LOHH... DIDALAM JIKA INGIN MEMESAN MAKANAN SILAHKAN KLIK VIEW MENU DIBAWAH INI TERIMA KASIH
                    </span>
                </div>
                <div class="w-full h-full flex justify-center py-8">
                    <a href="./user/index.php" class="py-4 px-8 text-center font-bold text-white rounded text-xl bg-blue-500 hover:bg-blue-600">View Menu</a>
                </div>
            </div>
        </div>
    </div>
</body>

</html>