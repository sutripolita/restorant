<?php

$connection = mysqli_connect("localhost","root","","project_pbo");

?>