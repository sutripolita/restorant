<?php

include("../config.php");
session_start();
if ($_SESSION["user"] == "") {
    echo "
    <script>
        alert('harap login terlebih dahulu')
        document.location.href = '../auth/login.php'
    </script>
    ";
}

$menus = mysqli_query($connection,"select * from tb_menu");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../dist/output.css">
</head>
<body class="bg-blue-200">
    <div class="flex justify-center items-center flex-col">
        <nav class="w-full py-4 px-8 border-b shadow-lg flex justify-between items-center bg-blue-400">
            <span class="text-xl font-bold">Selamat Datang, <?= $_SESSION["user"] ?></span>
            <a href="../auth/logout.php" class="text-xl font-bold">Logout</a>
        </nav>
        <div class="w-2/3 h-full bg-blue-100 border shadow-lg p-4 my-20">
            <table class="table-auto w-full h-full">
                <thead>
                    <tr>
                        <th class="p-3 border-b text-xl">Menu</th>
                        <th class="p-3 border-b text-xl">Image</th>
                        <th class="p-3 border-b text-xl">Price</th>
                    </tr>
                </thead>
                <?php while($row = mysqli_fetch_assoc($menus)) : ?>
                <tbody>
                    <tr class="text-center">
                        <td class="p-3 border-b text-lg font-semibold"><?= $row["name_menu"] ?></td>
                        <td class="p-3 border-b text-lg font-semibold flex justify-center items-center">
                            <img src="../img/menu/<?= $row["image_menu"] ?>" class="rounded w-52 h-52">
                        </td>
                        <td class="p-3 border-b text-lg font-semibold"><?= $row["price_menu"] ?></td>
                    </tr>
                </tbody>
                <?php endwhile?>
            </table>
        </div>
    </div>
</body>
</html>